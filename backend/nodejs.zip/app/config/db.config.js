module.exports = {
  HOST: "localhost",
  PORT: 27017,
  url: "mongodb+srv://zuber_95:9827581883@Ln@cluster0.ynp7n.mongodb.net/interviewtask?retryWrites=true&w=majority"

};