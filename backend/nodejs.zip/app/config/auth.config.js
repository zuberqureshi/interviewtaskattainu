module.exports = {
  secret: "zuber-secret-key"
};
